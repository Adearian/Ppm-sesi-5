package com.example.tugassesi5_herusubaktippm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
